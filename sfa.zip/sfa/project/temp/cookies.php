<?php
echo strlen($_COOKIE["username"]);
echo " ".$_COOKIE["username"]."<br>";
echo strlen($_COOKIE["password"]);
echo " ".$_COOKIE["password"]."<br>";
?>

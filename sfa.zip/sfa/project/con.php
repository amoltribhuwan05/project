<?php $conn = pg_connect("host=localhost port=5432 dbname=attend user=amol password=123");?>
